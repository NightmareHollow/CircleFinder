namespace CircleFinding
{
    public class LinearFunctionCoefficients
    {
        public float a { get; }
        public float b { get; }

        public LinearFunctionCoefficients(float a, float b)
        {
            this.a = a;
            this.b = b;
        }
    }
}