﻿using System;

namespace CircleFinding
{
  internal class Program
  { 
      //Here we think that our functions are tangents
    private static float Tangent1(float xVal)
    {
      return 1f / 3f * xVal;
    }

    private static float Tangent2(float xVal)
    {
      return 4f / 3f * xVal;
    }
    
    public static void Main(string[] args)
    {
        const float pointX = 3f;
        const float pointY = 2f;
        
      Point point = new Point(pointX, pointY);
      Circle foundCircle = FindCircle(Tangent1, Tangent2, point);
                
      if (foundCircle == null)
      {
        //Special case may be specified
        Console.Write("Circle not found(special case or parallel lines");
      }
      else
      {
        Console.Write(foundCircle.ToString());
      }
      
    }
    
    public static Circle FindCircle(Func<float, float> firstTangent, Func<float, float> secondTangent, Point coord)
    {
            if (firstTangent == null || secondTangent == null || coord == null)
                return null;

            LinearFunctionCoefficients firstTangentCoefficients = FindLinearFunctionCoefficients(firstTangent);
            LinearFunctionCoefficients secondTangentCoefficients = FindLinearFunctionCoefficients(secondTangent);

            Point tangentsCrossPoint = FindLinearFunctionsCrossPoint(firstTangentCoefficients, secondTangentCoefficients);
            if (tangentsCrossPoint == null)
            {
                Console.Write("Your tangents are parallel");
                return null;
            }

            LinearFunctionCoefficients bisectorLinearCoefficients = FindLinearFunctionsBisector(firstTangentCoefficients,
                secondTangentCoefficients, tangentsCrossPoint);

            //Can be done in another function
            float bisectorASquare = bisectorLinearCoefficients.a * bisectorLinearCoefficients.a;
            
            float divideVal = firstTangentCoefficients.a * firstTangentCoefficients.a + 1f;

            float ar = bisectorASquare + 1;
            float br = 2 * bisectorLinearCoefficients.a * bisectorLinearCoefficients.b - 2 * coord.x - 2 * coord.y * bisectorLinearCoefficients.a;
            float cr = coord.x * coord.x + bisectorLinearCoefficients.b * bisectorLinearCoefficients.b -
                      2 * coord.y * bisectorLinearCoefficients.b + coord.y * coord.y;

            float al = (firstTangentCoefficients.a * firstTangentCoefficients.a + bisectorASquare
                        - 2 * firstTangentCoefficients.a * bisectorLinearCoefficients.a) / divideVal;
            float bl = 2 * (bisectorLinearCoefficients.a * bisectorLinearCoefficients.b - firstTangentCoefficients.a * bisectorLinearCoefficients.b +
                            firstTangentCoefficients.a * firstTangentCoefficients.b - firstTangentCoefficients.b * bisectorLinearCoefficients.a) / divideVal;
            float cl = (bisectorLinearCoefficients.b * bisectorLinearCoefficients.b + firstTangentCoefficients.b * firstTangentCoefficients.b -
                        2 * firstTangentCoefficients.b * bisectorLinearCoefficients.b) / divideVal;

            float a = ar - al;
            float b = br - bl;
            float c = cr - cl;
            
            // it's parabolic function, has two answers, so i get only the highest
            float discriminant = b * b - 4 * a * c;
            if (discriminant < 0f)
            {
                Console.Write("There are no answers");
                return null;
            }

            float centerX = (-b + (float) Math.Sqrt(discriminant)) / (2f * a);
            float centerY = bisectorLinearCoefficients.a * centerX + bisectorLinearCoefficients.b;

            float length = Math.Abs(firstTangentCoefficients.a * centerX - centerY + firstTangentCoefficients.b);
            float sqrt = (float) Math.Sqrt(divideVal);
            float radius = length / sqrt;

            return new Circle(new Point(centerX, centerY), radius);
    }

    private static LinearFunctionCoefficients FindLinearFunctionCoefficients(Func<float, float> linearFunction)
    {
        if (linearFunction == null)
            return null;

        float a = linearFunction.Invoke(1f) - linearFunction.Invoke(0f);
        float b = linearFunction.Invoke(0f);

        return new LinearFunctionCoefficients(a, b);
    }

    private static Point FindLinearFunctionsCrossPoint(LinearFunctionCoefficients firstCoefficients, LinearFunctionCoefficients secondCoefficients)
    {
        if (firstCoefficients.a - secondCoefficients.a == 0f)
            return null;

        float x = (secondCoefficients.b - firstCoefficients.b) / (firstCoefficients.a - secondCoefficients.a);
        float y = firstCoefficients.a * x + firstCoefficients.b;
        return new Point(x, y);
    }

    private static LinearFunctionCoefficients FindLinearFunctionsBisector(LinearFunctionCoefficients firstCoefficients,
        LinearFunctionCoefficients secondCoefficients, Point crossPoint)
    {
        float tangentCoefficientsMultiple = firstCoefficients.a * secondCoefficients.a;
        if (Math.Abs(tangentCoefficientsMultiple - 1f) < 0.001f)
        {
            //Specific case : tg is undefined
            return null;
        }

        float sumTangentCoefficient = (firstCoefficients.a + secondCoefficients.a) / (1f - tangentCoefficientsMultiple);
        float sumAngle = (float) Math.Atan(sumTangentCoefficient);
        float bisectorTangentCoefficient = (float) ((1f - Math.Cos(sumAngle)) / Math.Sin(sumAngle));

        float b = crossPoint.y - bisectorTangentCoefficient * crossPoint.x;

        return new LinearFunctionCoefficients(bisectorTangentCoefficient, b);
    }
  }
}